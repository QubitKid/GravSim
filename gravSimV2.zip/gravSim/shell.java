import org.jsfml.system.*;
import org.jsfml.window.*;
import org.jsfml.window.event.*;
import java.util.LinkedList;
import java.util.Random;

import java.awt.Color;
import java.util.Vector;

import org.jsfml.graphics.*;

public class shell
{
    private Random RandGen = new Random();
    private RenderWindow shell;
    private boolean badStart = true;
    private LinkedList<Entity> e = new LinkedList<Entity>();
    private PhysicsHandler physics = new PhysicsHandler();
    private static int numberOfBalls;

    public static void main (String[] args){
        //creates new instance of this class to begin running the shell window
       shell s = new shell(args);
        
    }
    /**
     * Instantiates the class and creates a new Window
     */
    private shell(String[] args){
        shell = new RenderWindow();
        shell.create((new VideoMode(650, 650)), "Gravity Sim V2", WindowStyle.CLOSE | WindowStyle.TITLEBAR);
        numberOfBalls = 10;
        System.out.println(args.length);

        if (args.length > 0) {
            try {
                numberOfBalls = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Argument must be an integer.");
                System.exit(1);
            }
        }
        run(shell);
    }

    /**
     * Runs the simulator
     * @param w, the renderwindow to display the balls in
     */
    private void run(RenderWindow w){
        //create balls and avoid filling the same space with more than one ball
        int maxEfforts = 0;
        while(badStart && maxEfforts < 5000){
            badStart = false;
           fillList(e);
           System.out.println("Ball overlap has occured. Trying spawn again.");
           maxEfforts++;
           if(maxEfforts == 5000){
               w.close();
               System.out.println("Can not spawn balls. Try smaller number.");
           }
        }

        
        float timeElapsed = 0f;
        //time steps
        float dt = 1/100f;

        while(w.isOpen()){
            //refresh
            w.clear();
            //update balls
            if(!badStart){
                for(Entity ent : e){
                    ent.moveEntity(timeElapsed, dt);
                    w.draw(ent.returnShape());
                    findDistance(e, ent);
                }

                timeElapsed  += dt;

                //displaye the balls on the window
                
                w.display();
            }

            //closes the shell on exit press
            for (Event event : w.pollEvents()) {
                switch(event.type) {
                    case CLOSED:
                        w.close();
                        System.exit(0);
                        break;
                }
            }
        }
    }

    /**
     * This method creates all the balls and populates a linked list of entities
     * @param e, the LinkedList to be filled
     * @return e, the filled linked list
     */
    private LinkedList<Entity> fillList(LinkedList<Entity> e){
        //try to create balls
        for(int i = 0; i < numberOfBalls; i++) {e.add(new Entity(RandGen.nextInt(4)+ 4, RandGen.nextInt(shell.getSize().x), RandGen.nextInt(shell.getSize().y), 0, RandGen.nextInt(300) - 120, RandGen.nextInt(50) - 50, shell.getSize()));}
        
        //make sure no balls exist in same space at spawn
        for(Entity E : e) {
            //set the mass of each ball
            E.setMass(findMass(E.returnRadius()));
            for(Entity Eother: e){
                if(E.getID() != Eother.getID()){
                    if(findDistanceBetween(E, Eother)){
                         //if two balls are overlapping, move one by its radius to get rid of overlap
                         while(findDistanceBetween(E, Eother)){
                            E.setXposition(E.getPosition().x + E.getRadius() + Eother.getRadius());
                            badStart = true;
                        }
                        badStart = false;;
                    }
                }
            }
        }
        //return the list
        return e;
    }

    /**
     * This is a basic function to find the mass of an object based on its radius
     * @param x, the radius of the entity
     * @return float, the mass
     */
    private float findMass(int x) {return (float)(4 * 3.14 * (x*x)) / 5;}

    /**
     * This method is used to check if balls have overlapped, if the distance between
     * the center of two balls is less than both the radii of the balls added together
     * @param e, the linked list of entities
     * @param E, the single Entity of the looper to check against all other balls
     */
    private void findDistance(LinkedList<Entity> e, Entity E){
        for(Entity Eother : e){
            //dont check to see if a ball is colliding with itself
            if(E.getID() != Eother.getID()){
                float xDiff= ((Eother.getPosition().x - E.getPosition().x));
                float yDiff = ((Eother.getPosition().y - E.getPosition().y));
                float dist = (float)Math.sqrt(((Math.pow(xDiff, 2))  + (Math.pow(yDiff, 2))));

                //if balls are overlapping or touching, a collision has occured
                if(dist <= (float)(E.getRadius() + Eother.getRadius())){
                    physics.solveCollision(E, Eother);
                    //redraw with new velocities
                    shell.draw(E.returnShape());
                    shell.draw(Eother.returnShape());
                }
            }
        }
    }

    /**
     * Method used to allow more balls to spawn, by moving the overlapping balls, instead of respawning every single ball
     * @param E, the first overlapping ball
     * @param Eother, the second overlapping ball
     * @return boolean, true if there is an overlap
     */
    private boolean findDistanceBetween(Entity E, Entity Eother){
        
        if(E.getID() != Eother.getID()){
            float xDiff= ((Eother.getPosition().x - E.getPosition().x));
            float yDiff = ((Eother.getPosition().y - E.getPosition().y));
            float dist = (float)Math.sqrt(((Math.pow(xDiff, 2))  + (Math.pow(yDiff, 2))));

            //if balls are overlapping or touching, a collision has occured
            if(dist <= (float)(E.getRadius() + Eother.getRadius())){
               
                return true;
            }
        }
        
        return false;
    }
}