
import org.jsfml.system.*;
import org.jsfml.window.*;
import org.jsfml.window.event.*;

import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.Vector;



import org.jsfml.graphics.*;

 
public class Entity extends CircleShape{

    private double xVel;
    private double yVel;
    private static final int TERMINAL_V = 300;
    private static final double GRAVITY = 9.81;

    private Vector<Double> velocity = new Vector<Double>();
  
   
    //0 for perfect inelastic, 1 for elastic.
    private static final double COR = 0.6;

    private boolean peak = false;
    private boolean forwardDir;

    private Vector2i shellSize;
    private boolean onGround = false;
    private int r;


    private static int IDstatic = 0;
    private int ID;

    private float mass;

    /**
     * Creates an entity
     * @param r, the radius of the ball
     * @param x, the Xposition of the ball
     * @param y, the Yposition of the ball
     * @param m, the mass of the ball
     * @param xVel, inital x axis velocity
     * @param yVel, intial y axis velocity
     * @param shellSize, the size of the window
     */
    public Entity(int r, int x, int y, float m, int xVel, int yVel, Vector2i shellSize){
        super(r);
        this.setFillColor(Color.MAGENTA);
        this.r = (int)this.getRadius();
        velocity.add(0,0.0);
        velocity.add(1,0.0);
        this.mass = m;
        this.shellSize = shellSize;
        if(xVel > 0) forwardDir = true;
        if(xVel < 0) forwardDir = false;
        setID();
        setVel(xVel, yVel);
        this.ID = IDstatic;
        //sets the balls origin as the centre
        this.setOrigin((this.getGlobalBounds().width / 2), this.getGlobalBounds().height/2);
        //sets position to the centre of the ball
        this.setXposition(x + r);
        this.setYposition(y + r);
    }

    /**
     * Method used when updating the Entites velocity vector
     * @param xVel, the x component of the velocity
     * @param yVel, the y component of the velocity
     */
    private void setVel(double xVel, double yVel){
        this.velocity.set(0, xVel);
        this.velocity.set(1, yVel);
    }

    /**
     * Responsible for applying the velcoties of the ball, gravity, friction, and air resistance. 
     * Also checks ball is within the bounds of the window
     * @param t, timeelapsed since beginning
     * @param dt, the increments in time
     */
    public void moveEntity(float t, float dt){    

        //checks if the ball has hit the bottom of the window
        //applies directional friction once ball is on the ground
        if(this.getPosition().y + this.getGlobalBounds().height/2 >=  shellSize.y){
            if(velocity.get(0) != 0.0){
                if(velocity.get(0) > 0.0 ){
                    //friction application in positive direction
                    velocity.set(0, velocity.get(0) - (0.1 * mass * GRAVITY * dt));
                    onGround = true;
                    forwardDir = true;
                } 
                if(velocity.get(0) < 0.0) {
                    //friction application in negative direction
                    velocity.set(0, velocity.get(0) + (0.1 * mass * GRAVITY * dt));
                    onGround = true;
                    forwardDir = false;
                }
            }  
        }
        else{
            //air resistance application, in x axis for both directions of travel
            if(velocity.get(0) > 0.0 ){
                //friction application in positive direction
                velocity.set(0, velocity.get(0) - (0.1 * mass * 0.01 * dt));
                forwardDir = true;
            } 
            if(velocity.get(0) < 0.0) {
                //friction application in negative direction
                velocity.set(0, velocity.get(0) + (0.1 * mass * 0.01 * dt));
                forwardDir = false;
            }
        }

        //check if the ball is about to leave either edge of the screen, reverse its velocity, and set its position accordingly.
        if(this.getPosition().x + this.getGlobalBounds().width/2 >= shellSize.x ){
            setVel((-velocity.get(0) * COR), velocity.get(1));
            forwardDir = false;
            this.setXposition(shellSize.x - this.getGlobalBounds().width/2);
        }
        else if (this.getPosition().x <= 0 + this.getGlobalBounds().width/2){
            setVel((-velocity.get(0) * COR), velocity.get(1));
            forwardDir = true;
            this.setXposition(0 + this.getGlobalBounds().width/2);
        }

        //had to use multiply to allow for greater mass causing faster acceleration, as acting in opposite direction on y axis

        //COMMENT OUT FOR ZERO GRAVITY
        this.velocity.set(1, this.velocity.get(1) + (GRAVITY * mass) * dt);

        //terminal velocity checks
        if(this.velocity.get(1) >= TERMINAL_V) this.velocity.set(1,(double)TERMINAL_V);
        if(this.velocity.get(0) >= TERMINAL_V) this.velocity.set(0,(double)TERMINAL_V);

        //set new position of entity after velocity changes
        this.setYposition((float)(this.getPosition().y + velocity.get(1) * dt));
        this.setXposition((float)(this.getPosition().x + velocity.get(0) * dt));


         //checks if the entity has hit with the floor
        if(this.getPosition().y >= (shellSize.y - this.getGlobalBounds().height/2) ){
            this.velocity.set(1, -this.velocity.get(1) * COR);
            Vector2f pos = new Vector2f(this.getPosition().x, shellSize.y - this.getGlobalBounds().height/2);
            this.setPosition(pos);
        } 
        if(this.getPosition().y <= 0 + this.getGlobalBounds().height/2){
            this.velocity.set(1, -this.velocity.get(1) * COR);
            Vector2f pos = new Vector2f(this.getPosition().x, 0 + this.getGlobalBounds().height/2);
            this.setPosition(pos);
        }

    }

    /**
     * Return ball ID 
     */
    public int getID(){ return this.ID;}

    /**
     * Set the y co ordinate of a ball
     * @param f, the y coordinate
     */
    private void setYposition(float f) {this.setPosition(new Vector2f(this.getPosition().x, f));}

    /**
     * Set the x co ordinate of the ball
     * @param f, the x co ordinate
     */
    private void setXposition(float f) {this.setPosition(new Vector2f(f,this.getPosition().y));}

    /**
     * Set the xVel component
     * @param x, the velocity in the x axis
     */
    public void setXvel(double x) {this.velocity.set(0, x);}

    /**
     * Set the yVel component
     * @param y, the velocity in the y axis
     */
    public void setYvel(double y) {this.velocity.set(1, y);}

    /**
     * Return the Entity Y velocity
     * @return double
     */
    public double getYvel() {return this.velocity.get(1);}

    /**
     * Return the entity velocity vector
     * @return Vector<Double>
     */
    public Vector<Double> getVel() {return this.velocity;}

    /**
     * Return the x velocity component
     * @return double
     */
    public double getXvel() {return this.velocity.get(0);}

    /**
     * Different method to return Entity radius, can also use super getRadius()
     * @return int
     */
    public int returnRadius() {return this.r;}

    /**
     * Method used to set the mass of the object
     * @param m, the objects mass
     */
    public void setMass(float m) {this.mass = m;}

    /**
     * Returns the mass of the object.
     * @return float
     */
    public float getMass() {return this.mass;}

    /**
     * Returns the CircleShape of the entity
     * @return CircleShape
     */
    public CircleShape returnShape() {return this;}


    /**
     * Check if the ball is on the ground, used to apply friction
     * @return boolean, true if on the ground
     */
    public boolean isOnGround() {return this.onGround;}

    /**
     * Used in startup to allocate each ball an ID
     */
    private static void setID() {IDstatic+=1;} 

    /**
     * Set the new velocity for this body
     * @param newV
     */
    public void setNewV(Vector<Double> newV) {this.velocity = newV;}
    
    //empty constructor for initial initialisation
    public Entity(){}
 
}