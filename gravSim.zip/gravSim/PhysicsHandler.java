import java.util.Vector;

public class PhysicsHandler{

    public PhysicsHandler(){}

    /**
     * This method takes the vector velocity of a body, and its angle of contact, and rotates the axis to allow for 
     * a 1D velocity collision equation.
     * It can then also be used to rotate the vectors after this equation back into 2D.
     * @param v, the velocity vector of a body
     * @param angle, the angle of contact of the two bodys, or angle of required rotation.
     * @return Vector<Double> , the new velocity vector after rotation
     */
    private Vector<Double> rotate(Vector<Double> v, double angle){
        Vector<Double> newVelocities = new Vector<Double>();
        newVelocities.add(0, v.get(0) * Math.cos(angle) - v.get(1) * Math.sin(angle));
        newVelocities.add(1, v.get(0) * Math.sin(angle) + v.get(1) * Math.cos(angle));
        return newVelocities;
        //the rotated vector velocity to simplifiy the physics
    }
    

    /**
     * This method takes two entities that have collided, and rotates their velocities
     * to perform a 1d elastic collision check, and then re rotates the velocities
     * into 2D. It then applies these new final velocities to the balls after contact.
     * @param e, The first body.
     * @param eOther, The second body.
     */
    public void solveCollision(Entity e, Entity eOther){
        double xPosDelta = e.getXvel() - eOther.getXvel();
        double yPosDelta = e.getYvel() - eOther.getYvel();
        double xDiff = eOther.getPosition().x - e.getPosition().x;
        double yDiff = eOther.getPosition().y - e.getPosition().y;

        //stop the balls being able to overlap
        if((xPosDelta * xDiff) + (yPosDelta * yDiff) >= 0){
            //the angle of contact between the two entities

            double angle = -Math.atan2(((double)eOther.getPosition().y - e.getPosition().y), (double)(eOther.getPosition().x - e.getPosition().x));

            //before rotating axis to do 1D collision
            Vector<Double> ebefore = rotate(e.getVel(), angle);
            Vector<Double> eObefore = rotate(eOther.getVel(), angle);

            //velocity after rotated 1D elastic collision
            Vector<Double> eafter = new Vector<Double>();
            Vector<Double> eOafter = new Vector<Double>();        

            //changing vectors for after rotating axes, applying physics formulae
            eafter.add(0, (double)(ebefore.get(0) * (e.getMass() - eOther.getMass()) / 
                (e.getMass() + eOther.getMass()) + eObefore.get(0) * 2 * eOther.getMass() / (e.getMass() + eOther.getMass())));
            eafter.add(1, ebefore.get(1));

            eOafter.add(0, (double)(eObefore.get(0) * (e.getMass() - eOther.getMass()) / 
                (e.getMass() + eOther.getMass()) + ebefore.get(0) * 2 * e.getMass() / (e.getMass() + eOther.getMass())));
            eOafter.add(1, eObefore.get(1));

            
            //final velocity after restoring axis orientation
            Vector<Double> vFinal = rotate(eafter, -angle);
            Vector<Double> vOFinal = rotate(eOafter, -angle);

            //sets the new velocites after the collision to the entities
            e.setNewV(vFinal);
            eOther.setNewV(vOFinal);
        }
    }
}